1 - Create and Activate virtual Enviroment 
''' git bash '''
---> python -m venv venv
---> source venv/Scripts/activate

2 - 
 pip install fastapi uvicorn[standard]
 